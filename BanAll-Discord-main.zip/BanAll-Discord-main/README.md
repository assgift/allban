# BanAll-Discord
Un script qui permet ban touts les membres d'un serveur.

1 ) faire un bot dans l'application de developer portal : https://discord.com/developers/applications

2 ) Allez dans l'onglet bot , et cochez les cases ![Mictures](https://cdn.discordapp.com/attachments/817843204740349982/831359958540091432/unknown.png)

3 ) Télechargez le fichier

4 ) configurer le config.json (token/prefix)

5 ) lancer le banall_start.bat
